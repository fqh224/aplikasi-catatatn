//import CONFIG from './config'; // Impor CONFIG untuk CACHE_NAME
import { precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { CacheableResponsePlugin } from 'workbox-cacheable-response';
import { NetworkFirst, CacheFirst, StaleWhileRevalidate } from 'workbox-strategies';
import { BASE_URL } from './config';
const { CACHE_NAME } = CONFIG;

const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/app.bundle.js',
  '/app.css',
  '/manifest.json',
  '/favicon.png',
  '/icons/icon-72x72.png',
  '/icons/icon-96x96.png',
  '/icons/icon-128x128.png',
  '/icons/icon-144x144.png',
  '/icons/icon-152x152.png',
  '/icons/icon-192x192.png',
  '/icons/icon-384x384.png',
  '/icons/icon-512x512.png',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
  // Tambahkan aset lain yang statis dan penting
];

const manifest = self.__WB_MANIFEST;
precacheAndRoute(self.__WB_MANIFEST);

registerRoute(
  ({ url }) => {
    return url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com';
  },
  new CacheFirst({
  cacheName: 'google-fonts',
}),

);

registerRoute(
  ({ url }) => {
    return url.origin === 'https://cdnjs.cloudflare.com' || url.origin.includes('fontawesome');
  },
  new CacheFirst({
    cacheName: 'fontawesome',
  }),
);

registerRoute(
  ({ url }) => {
    return url.origin === 'https://ui-avatars.com';
  },
  new CacheFirst({
    cacheName: 'avatars-api',
    plugins: [
      new CacheableResponsePlugin({
        statuses: [0, 200],
      }),
    ],
  }),
);

registerRoute(
  ({ url }) => {
    const baseUrl = new URL(BASE_URL);
    return baseUrl.origin === url.origin && request.destination !== 'image';
  },
  new NetworkFirst({
    cacheName: 'storyapp-cache-v1',
  }),
);


registerRoute(
  ({ request, url }) => {
    const baseUrl = new URL(BASE_URL);
    return baseUrl.origin === url.origin && request.destination === 'image';
  },
  new StaleWhileRevalidate({
    cacheName: 'storyapp-cache-v1-images',
  }),
);

registerRoute(
  ({ url }) => {
    return url.origin.includes('leaflet');
  },
  new CacheFirst({
    cacheName: 'leaflet-api',
  }),
);


self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Service Worker: Caching app shell');
      return cache.addAll(URLS_TO_CACHE);
    }).catch(error => {
      console.error('Service Worker: Failed to cache app shell:', error);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Service Worker: Deleting old cache', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim(); // Mengambil kontrol halaman yang terbuka segera
});

self.addEventListener('fetch', (event) => {
  // Hanya menangani request GET
  if (event.request.method !== 'GET') {
    return;
  }

  // Strategi Cache First untuk aset yang sudah di-cache
  if (URLS_TO_CACHE.includes(event.request.url.replace(self.location.origin, ''))) {
     event.respondWith(
      caches.match(event.request).then((response) => {
        return response || fetch(event.request).then((fetchResponse) => {
          // Cache a copy of the response if it's a valid response
          if (fetchResponse && fetchResponse.status === 200) {
            const responseToCache = fetchResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return fetchResponse;
        });
      }).catch(() => {
        // Jika gagal dari cache dan network, coba berikan fallback jika ada
        // Misalnya, halaman offline kustom:
        // if (event.request.mode === 'navigate') {
        //   return caches.match('/offline.html'); // Anda perlu membuat offline.html
        // }
      })
    );
    return;
  }

  // Strategi Network First untuk API atau sumber daya dinamis lainnya
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Jika response valid, clone dan simpan ke cache
        if (response && response.status === 200) {
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return response;
      })
      .catch(() => {
        // Jika network gagal, coba ambil dari cache
        return caches.match(event.request).then((cachedResponse) => {
          return cachedResponse || Response.error(); // Jika tidak ada di cache juga, kembalikan error
        });
      })
  );
});

self.addEventListener('push', (event) => { //
  console.log('Service Worker: Push event received.');

  let notificationData = {};
  try {
    if (event.data) {
      notificationData = event.data.json(); //
    }
  } catch (error) {
    console.error('Service Worker: Failed to parse push data JSON', error);
    // Fallback notification if data is not JSON or not present
    notificationData = {
      title: 'New Notification',
      options: {
        body: 'You have a new message.',
        icon: 'icons/icon-192x192.png', // Default icon
      },
    };
  }

  const title = notificationData.title || 'Faqih Story App Notification'; //
  const options = { //
    body: notificationData.options?.body || 'You have new stories!', //
    icon: notificationData.options?.icon || 'icons/icon-192x192.png',
    badge: notificationData.options?.badge || 'icons/icon-72x72.png',
    // Tambahkan opsi lain jika diperlukan:
    // vibrate: [200, 100, 200],
    // data: { url: '<url-to-open-on-click>' }, // Untuk menangani klik notifikasi
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Notification click received.', event.notification);
  event.notification.close();

  // Contoh: Buka URL tertentu ketika notifikasi diklik
  // const urlToOpen = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';
  // event.waitUntil(
  //   clients.matchAll({ type: 'window' }).then((windowClients) => {
  //     for (let i = 0; i < windowClients.length; i++) {
  //       const client = windowClients[i];
  //       if (client.url === urlToOpen && 'focus' in client) {
  //         return client.focus();
  //       }
  //     }
  //     if (clients.openWindow) {
  //       return clients.openWindow(urlToOpen);
  //     }
  //   })
  // );
});