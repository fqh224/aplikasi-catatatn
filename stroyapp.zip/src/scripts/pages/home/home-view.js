// View for Home page
import { showFormattedDate } from '../../utils/index';

export default class HomeView {
  constructor() {
    this.storiesContainer = null;
    this.mapContainer = null;
  }
  
  getTemplate() {
    return `
      <section class="container">
        <h1 class="section-title">Stories</h1>
        <div class="story-map-container">
          <div id="storyMap" class="story-map" tabindex="0" aria-label="Map showing story locations"></div>
        </div>
        <div id="storiesContainer" class="stories-container">
          <p class="loading-text">Loading stories...</p>
        </div>
      </section>
    `;
  }
  
  initElements() {
    this.storiesContainer = document.getElementById('storiesContainer');
    this.mapContainer = document.getElementById('storyMap');
  }
  
  showLoading() {
    this.storiesContainer.innerHTML = '<p class="loading-text">Loading stories...</p>';
  }
  
  showError(message) {
    this.storiesContainer.innerHTML = `<p class="error-text">${message}</p>`;
  }
  
  showEmptyMessage() {
    this.storiesContainer.innerHTML = '<p>No stories found. Be the first to create one!</p>';
  }

  showInfoMessage(message) {
    const infoElement = document.createElement('p');
    infoElement.className = 'info-text';
    infoElement.textContent = message;
    this.storiesContainer.prepend(infoElement);
  }
  
  displayStories(stories, isLoggedIn) {
    this.storiesContainer.innerHTML = '';
    
    if (!isLoggedIn) {
      this.storiesContainer.innerHTML += `
        <div class="login-prompt">
          <p>You are viewing a limited preview. Please <a href="#/login">login</a> to see all stories and access more features.</p>
        </div>
      `;
    }

    // Add story cards
    if (stories && stories.length > 0) {
      stories.forEach(story => {
        const storyCard = this.createStoryCard(story, isLoggedIn);
        this.storiesContainer.innerHTML += storyCard;
      });
    } else {
      this.storiesContainer.innerHTML += '<p>No stories available.</p>';
    }
  }

  createStoryCard(story, isLoggedIn) {
    const linkHref = isLoggedIn ? `#/story/${story.id}` : '#/login';
    
    return `
      <article class="story-card">
        <a href="${linkHref}" class="story-link" ${!isLoggedIn ? 'title="Login required to view story details"' : ''}>
          <div class="story-image-container">
            <img src="${story.photoUrl}" alt="${story.name}'s story" class="story-image" loading="lazy">
          </div>
          <div class="story-content">
            <h3 class="story-title">${story.name}</h3>
            <p class="story-date">${showFormattedDate(story.createdAt)}</p>
            <p class="story-description">${story.description}</p>
            ${story.lat && story.lon ? `<p class="story-location">📍 Location: ${story.lat.toFixed(2)}, ${story.lon.toFixed(2)}</p>` : ''}
            ${!isLoggedIn ? '<p class="login-hint" style="color: var(--info-color); font-size: 0.85rem; margin-top: 10px;">Login to view full details</p>' : ''}
          </div>
        </a>
      </article>
    `;
  }
}
