import routes from '../routes/routes';
import { getActiveRoute, parseActivePathname } from '../routes/url-parser';
import Auth from '../data/auth';
import { updateTheDOMCallback } from '../utils/view-transition';

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;
  #skipLink = null;
  #auth = null;

  constructor({ navigationDrawer, drawerButton, content, skipLink }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;
    this.#skipLink = skipLink;
    this.#auth = new Auth();

    this._setupDrawer();
    this._setupSkipToContent();
    this._updateNavigation();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener('click', () => {
      this.#navigationDrawer.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove('open');
      }

      this.#navigationDrawer.querySelectorAll('a').forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove('open');
        }
      });
    });
  }

  _setupSkipToContent() {
    if (this.#skipLink) {
      this.#skipLink.addEventListener('click', (event) => {
        event.preventDefault();
        this.#content.focus();
      });
    }
  }

  _updateNavigation() {
    const navList = document.querySelector('#nav-list');
    const isLoggedIn = this.#auth.isUserLoggedIn();
    
    setTimeout(() => {
      const logoutButton = document.getElementById('logout-button');
      if (logoutButton) {
        logoutButton.addEventListener('click', (event) => {
          event.preventDefault();
          this.#auth.logout();
          this._updateNavigation();
          window.location.hash = '#/';
        });
      }
    }, 100);

    if (isLoggedIn) {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/stories/add">Add Story</a></li>
        <li><a href="#/about">About</a></li>
        <li><button id="logout-button" class="nav-button">Logout</button></li>
      `;
    } else {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/login">Login</a></li>
        <li><a href="#/register">Register</a></li>
        <li><a href="#/about">About</a></li>
      `;
    }
  }

  async renderPage() {
    try {
      const url = getActiveRoute();
      const { id } = parseActivePathname();
      
      console.log('Current route:', url);
      console.log('Routes available:', Object.keys(routes));
      
      let page = routes[url];
      if (!page && url.includes('story') && id) {
        page = routes['/story/:id'];
      }
      
      if (!page) {
        console.warn(`No page found for route: ${url}, defaulting to home`);
        page = routes['/'];
      }

      this._updateNavigation();
      
      console.log('Rendering page:', page);
      
      updateTheDOMCallback(async () => {
        try {
          const content = await page.render();
          this.#content.innerHTML = content;
          window.scrollTo(0, 0);
          await page.afterRender();
        } catch (error) {
          console.error('Error rendering page:', error);
          this.#content.innerHTML = '<div class="container"><p class="error-text">Error loading page. Please try again.</p></div>';
        }
      });
    } catch (error) {
      console.error('Error in renderPage:', error);
      this.#content.innerHTML = '<div class="container"><p class="error-text">Something went wrong. Please try again.</p></div>';
    }
  }
}

export default App;
