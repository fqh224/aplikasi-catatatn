import Auth from '../../data/auth';
import { getAllSavedStoriesFromDB, removeSavedStoryFromDB, clearAllSavedStoriesFromDB } from '../../data/indexed-db';

export default class SavedStoriesPresenter {
  constructor({ view }) {
    this.view = view;
    this.auth = new Auth();
    this.allSavedStories = [];
    this.filteredStories = [];
  }

  async init() {
    if (!this.auth.isUserLoggedIn()) {
      window.location.hash = '#/login';
      return;
    }

    this.attachEventListeners();
    await this.loadSavedStories();
  }

  attachEventListeners() {
    this.view.registerSearchHandler(this.handleSearch.bind(this));
    this.view.registerSortHandler(this.handleSort.bind(this));
    this.view.registerClearAllHandler(this.handleClearAll.bind(this));
    this.view.registerRemoveStoryHandler(this.handleRemoveStory.bind(this));
  }

  async loadSavedStories() {
    try {
      this.view.showLoading();
      
      this.allSavedStories = await getAllSavedStoriesFromDB();
      this.filteredStories = [...this.allSavedStories];
      
      this.sortStories();
      this.view.displaySavedStories(this.filteredStories);
      
    } catch (error) {
      console.error('Error loading saved stories:', error);
      this.view.showError('Failed to load saved stories');
    }
  }

  handleSearch() {
    const query = this.view.getSearchQuery();
    
    if (query.trim() === '') {
      this.filteredStories = [...this.allSavedStories];
    } else {
      this.filteredStories = this.allSavedStories.filter(story =>
        story.name.toLowerCase().includes(query) ||
        story.description.toLowerCase().includes(query)
      );
    }
    
    this.sortStories();
    this.view.displaySavedStories(this.filteredStories);
  }

  handleSort() {
    this.sortStories();
    this.view.displaySavedStories(this.filteredStories);
  }

  sortStories() {
    const sortOption = this.view.getSortOption();
    const [field, order] = sortOption.split('-');
    
    this.filteredStories.sort((a, b) => {
      let valueA = a[field];
      let valueB = b[field];
      
      if (field === 'name') {
        valueA = valueA.toLowerCase();
        valueB = valueB.toLowerCase();
      }
      
      if (order === 'asc') {
        return valueA < valueB ? -1 : valueA > valueB ? 1 : 0;
      } else {
        return valueA > valueB ? -1 : valueA < valueB ? 1 : 0;
      }
    });
  }

  async handleRemoveStory(storyId, cardElement) {
    const confirmed = this.view.showConfirmDialog('Are you sure you want to remove this story from saved?');
    
    if (!confirmed) return;
    
    try {
      await removeSavedStoryFromDB(storyId);
      
      // Remove from arrays
      this.allSavedStories = this.allSavedStories.filter(story => story.id !== storyId);
      this.filteredStories = this.filteredStories.filter(story => story.id !== storyId);
      
      // Remove from DOM
      cardElement.remove();
      
      // Show empty message if no stories left
      if (this.filteredStories.length === 0) {
        this.view.showEmptyMessage();
      }
      
      this.view.showSuccessMessage('Story removed from saved');
      
    } catch (error) {
      console.error('Error removing saved story:', error);
      this.view.showToast('Failed to remove story', 'error');
    }
  }

  async handleClearAll() {
    if (this.allSavedStories.length === 0) {
      this.view.showSuccessMessage('No saved stories to clear');
      return;
    }
    
    const confirmed = this.view.showConfirmDialog(
      `Are you sure you want to remove all ${this.allSavedStories.length} saved stories? This action cannot be undone.`
    );
    
    if (!confirmed) return;
    
    try {
      await clearAllSavedStoriesFromDB();
      
      this.allSavedStories = [];
      this.filteredStories = [];
      
      this.view.showEmptyMessage();
      this.view.showSuccessMessage('All saved stories cleared');
      
    } catch (error) {
      console.error('Error clearing all saved stories:', error);
      this.view.showToast('Failed to clear saved stories', 'error');
    }
  }
}
