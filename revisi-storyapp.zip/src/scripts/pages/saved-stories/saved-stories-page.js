import SavedStoriesView from './saved-stories-view';
import SavedStoriesPresenter from './saved-stories-presenter';

export default class SavedStoriesPage {
  constructor() {
    this.view = new SavedStoriesView();
    this.presenter = null;
  }

  async render() {
    return this.view.getTemplate();
  }

  async afterRender() {
    this.view.initElements();
    
    this.presenter = new SavedStoriesPresenter({
      view: this.view
    });
    
    await this.presenter.init();
  }
}
