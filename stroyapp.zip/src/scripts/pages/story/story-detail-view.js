// View for Story Detail page
import { showFormattedDate } from '../../utils/index';

export default class StoryDetailView {
  constructor() {
    this.storyDetailContainer = null;
    this.lightbox = null;
    this.lightboxImg = null;
    this.lightboxCaption = null;
    this.lightboxClose = null;
  }

  getTemplate() {
    return `
      <section class="container">
        <div id="storyDetail" class="story-detail">
          <p class="loading-text">Loading story details...</p>
        </div>
        
        <!-- Image Lightbox Modal -->
        <div id="lightbox" class="lightbox">
          <span class="lightbox-close">&times;</span>
          <img id="lightbox-img" class="lightbox-content" src="" alt="Full story image">
          <div id="lightbox-caption" class="lightbox-caption"></div>
        </div>
      </section>
    `;
  }

  initElements() {
    this.storyDetailContainer = document.getElementById('storyDetail');
    this.lightbox = document.getElementById('lightbox');
    this.lightboxImg = document.getElementById('lightbox-img');
    this.lightboxCaption = document.getElementById('lightbox-caption');
    this.lightboxClose = document.querySelector('.lightbox-close');
    
    // Attach lightbox events immediately after elements are initialized
    this.attachLightboxEvents();
  }

  showLoading() {
    this.storyDetailContainer.innerHTML = '<p class="loading-text">Loading story details...</p>';
  }

  showError(message) {
    this.storyDetailContainer.innerHTML = `<p class="error-text">${message}</p>`;
  }

  showAuthRequired() {
    this.storyDetailContainer.innerHTML = `
      <div class="auth-required">
        <p>Please log in to view story details.</p>
        <a href="#/login" class="auth-button">Login</a>
      </div>
    `;
  }

  displayStoryDetail(story) {
    this.storyDetailContainer.innerHTML = `
      <div class="story-detail-header">
        <h1 class="story-detail-title">${story.name}'s Story</h1>
        <p class="story-detail-date">${showFormattedDate(story.createdAt)}</p>
      </div>
      
      <div class="story-detail-image-container">
        <img src="${story.photoUrl}" alt="${story.name}'s story" class="story-detail-image clickable" data-full-img="${story.photoUrl}" data-caption="${story.name}'s story">
        <div class="image-click-hint">Click image to enlarge</div>
      </div>
      
      <div class="story-detail-content">
        <p class="story-detail-description">${story.description}</p>
        
        ${story.lat && story.lon ? `
          <div class="story-detail-map-container">
            <div id="detailMap" class="story-detail-map" tabindex="0" aria-label="Map showing story location"></div>
          </div>
        ` : ''}
      </div>
      
      <div class="story-detail-actions">
        <a href="#/" class="back-button">← Back to stories</a>
        <button id="saveStoryBtn" class="save-story-button">
          <i class="far fa-bookmark"></i>
          <span class="save-text">Save Story</span>
        </button>
        <button id="deleteStoryBtn" class="save-story-button delete" style="display: none;">
          <i class="fas fa-trash"></i>
          <span class="delete-text">Delete Story</span>
        </button>
      </div>
    `;
    
    // Set up image lightbox event after DOM is updated
    setTimeout(() => {
      const storyImage = document.querySelector('.story-detail-image.clickable');
      if (storyImage) {
        storyImage.addEventListener('click', () => {
          this.openLightbox(storyImage.getAttribute('data-full-img'), storyImage.getAttribute('data-caption'));
        });
      }
    }, 100);

    return document.getElementById('detailMap');
  }

  updateSaveButtonState(isSaved) {
    const saveBtn = document.getElementById('saveStoryBtn');
    const deleteBtn = document.getElementById('deleteStoryBtn');
    
    if (isSaved) {
      saveBtn.style.display = 'none';
      deleteBtn.style.display = 'flex';
    } else {
      saveBtn.style.display = 'flex';
      deleteBtn.style.display = 'none';
    }
  }

  registerSaveStoryHandler(handler) {
    const saveBtn = document.getElementById('saveStoryBtn');
    if (saveBtn) {
      saveBtn.addEventListener('click', handler);
    }
  }

  registerDeleteStoryHandler(handler) {
    const deleteBtn = document.getElementById('deleteStoryBtn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', handler);
    }
  }

  showSaveMessage(message, isError = false) {
    // This method will be replaced with toast notifications
    // Keeping for backward compatibility but functionality moved to toast
  }

  openLightbox(imageUrl, caption) {
    this.lightboxImg.src = imageUrl;
    this.lightboxCaption.textContent = caption;
    this.lightbox.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  closeLightbox() {
    this.lightbox.style.display = 'none';
    document.body.style.overflow = 'auto';
  }

  attachLightboxEvents() {
    if (this.lightboxClose) {
      this.lightboxClose.addEventListener('click', () => {
        this.closeLightbox();
      });
    }
    
    if (this.lightbox) {
      this.lightbox.addEventListener('click', (event) => {
        if (event.target === this.lightbox) {
          this.closeLightbox();
        }
      });
      
      // Add keyboard support for ESC key
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && this.lightbox.style.display === 'flex') {
          this.closeLightbox();
        }
      });
    }
  }
}
