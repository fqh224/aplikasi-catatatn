import CONFIG from '../config';
import { showFormattedDate } from './index';

class Map {
  constructor({ mapElement, onLocationPicked = null }) {
    this.mapElement = mapElement;
    this.map = null;
    this.marker = null;
    this.onLocationPicked = onLocationPicked;
  }

  async initMap(lat = -6.175, lng = 106.827, zoom = 13) {
    return new Promise((resolve, reject) => {
      if (typeof L === 'undefined') {
        console.error('Leaflet library not loaded');
        this.mapElement.innerHTML = '<div class="error-text">Map library failed to load. Please refresh the page.</div>';
        reject(new Error('Leaflet not defined'));
        return;
      }
      
      try {
        console.log('Initializing map with coordinates:', lat, lng);
        this.map = L.map(this.mapElement).setView([lat, lng], zoom);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          maxZoom: 19,
        }).addTo(this.map);
  
        if (this.onLocationPicked) {
          this.map.on('click', (e) => {
            this.setMarker(e.latlng.lat, e.latlng.lng);
            this.onLocationPicked(e.latlng.lat, e.latlng.lng);
          });
        }
        
        setTimeout(() => {
          this.map.invalidateSize();
        }, 100);
        
        resolve(this.map);
      } catch (error) {
        console.error('Error initializing map:', error);
        this.mapElement.innerHTML = '<div class="error-text">Failed to initialize map. Please refresh the page.</div>';
        reject(error);
      }
    });
  }

  setMarker(lat, lng, popupContent = 'Selected Location') {
    try {
      if (!this.map) return { lat, lng };
      
      if (this.marker) {
        this.map.removeLayer(this.marker);
      }
      
      this.marker = L.marker([lat, lng]).addTo(this.map);
      this.marker.bindPopup(popupContent).openPopup();
      
      return { lat, lng };
    } catch (error) {
      console.error('Error setting marker:', error);
      return { lat, lng };
    }
  }
  
  showStoriesOnMap(stories) {
    try {
      if (!this.map || !Array.isArray(stories)) return;
      
      const storiesWithLocation = stories.filter(story => story.lat && story.lon);
      
      if (storiesWithLocation.length === 0) {
        console.log('No stories with location found');
        return;
      }
      
      storiesWithLocation.forEach(story => {
        const marker = L.marker([story.lat, story.lon]).addTo(this.map);
        
        const popupContent = `
          <div class="map-popup">
            <h3>${story.name}</h3>
            <img src="${story.photoUrl}" alt="${story.name}'s story" style="width: 150px; max-height: 100px; object-fit: cover;">
            <p>${story.description.substring(0, 100)}${story.description.length > 100 ? '...' : ''}</p>
            <p class="map-popup-date">Posted on: ${showFormattedDate(story.createdAt)}</p>
          </div>
        `;
        
        marker.bindPopup(popupContent);
      });
      
      if (storiesWithLocation.length > 0) {
        const bounds = L.latLngBounds(storiesWithLocation.map(story => [story.lat, story.lon]));
        this.map.fitBounds(bounds, { padding: [50, 50] });
      }
    } catch (error) {
      console.error('Error showing stories on map:', error);
    }
  }
}

export default Map;
