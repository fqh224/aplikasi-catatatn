// View for Add Story page
export default class AddStoryView {
  constructor() {
    this.startCameraBtn = null;
    this.takePhotoBtn = null;
    this.retakePhotoBtn = null;
    this.cameraPreview = null;
    this.photoCanvas = null;
    this.photoPreview = null;
    this.photoFileInput = null;
    this.fileNameDisplay = null;
    this.submitBtn = null;
    this.addStoryForm = null;
    this.messageContainer = null;
    this.selectedLocationText = null;
    this.mapContainer = null;
  }

  getTemplate() {
    return `
      <section class="container">
        <h1 class="section-title">Add New Story</h1>
        
        <form id="addStoryForm" class="add-story-form">
          <div class="form-group">
            <label for="description">Story Description</label>
            <textarea id="description" name="description" rows="4" required placeholder="Share your story..."></textarea>
          </div>
          
          <div class="form-group photo-input-container">
            <label>Photo</label>
            <div class="photo-options">
              <div class="option">
                <h3>Take a Photo</h3>
                <div class="camera-controls">
                  <button type="button" id="startCamera" class="camera-button">Start Camera</button>
                  <button type="button" id="takePhoto" class="camera-button" disabled>Take Photo</button>
                  <button type="button" id="retakePhoto" class="camera-button" disabled>Retake</button>
                </div>
                <video id="cameraPreview" class="camera-preview" autoplay playsinline></video>
                <canvas id="photoCanvas" class="photo-canvas" style="display:none;"></canvas>
              </div>
              
              <div class="option">
                <h3>Or Upload a Photo</h3>
                <div class="file-upload">
                  <input type="file" id="photoFile" class="file-input" accept="image/*">
                  <label for="photoFile" class="file-label">Choose file</label>
                  <p class="file-name" id="fileName">No file chosen</p>
                </div>
              </div>
            </div>
            
            <div id="photoPreview" class="photo-preview">
              <p>No photo selected</p>
            </div>
          </div>
          
          <div class="form-group">
            <label for="locationMap">Pick Location (Optional)</label>
            <div id="locationMap" class="location-map" tabindex="0" aria-label="Map for selecting story location"></div>
            <p id="selectedLocation" class="selected-location">No location selected</p>
          </div>
          
          <div id="storyMessage" class="form-message"></div>
          <button type="submit" id="submitStory" class="submit-button" disabled>Share Story</button>
        </form>
      </section>
    `;
  }

  initElements() {
    this.startCameraBtn = document.getElementById('startCamera');
    this.takePhotoBtn = document.getElementById('takePhoto');
    this.retakePhotoBtn = document.getElementById('retakePhoto');
    this.cameraPreview = document.getElementById('cameraPreview');
    this.photoCanvas = document.getElementById('photoCanvas');
    this.photoPreview = document.getElementById('photoPreview');
    this.photoFileInput = document.getElementById('photoFile');
    this.fileNameDisplay = document.getElementById('fileName');
    this.submitBtn = document.getElementById('submitStory');
    this.addStoryForm = document.getElementById('addStoryForm');
    this.messageContainer = document.getElementById('storyMessage');
    this.selectedLocationText = document.getElementById('selectedLocation');
    this.mapContainer = document.getElementById('locationMap');
  }

  registerCameraStartHandler(handler) {
    this.startCameraBtn.addEventListener('click', handler);
  }

  registerTakePhotoHandler(handler) {
    this.takePhotoBtn.addEventListener('click', handler);
  }

  registerRetakePhotoHandler(handler) {
    this.retakePhotoBtn.addEventListener('click', handler);
  }

  registerFileInputHandler(handler) {
    this.photoFileInput.addEventListener('change', handler);
  }

  registerFormSubmitHandler(handler) {
    this.addStoryForm.addEventListener('submit', handler);
  }

  registerHashChangeHandler(handler) {
    window.addEventListener('hashchange', handler);
  }

  // Camera UI methods
  showCameraPreview() {
    this.cameraPreview.style.display = 'block';
  }

  hideCameraPreview() {
    this.cameraPreview.style.display = 'none';
  }

  enableTakePhotoButton() {
    this.takePhotoBtn.disabled = false;
  }

  disableTakePhotoButton() {
    this.takePhotoBtn.disabled = true;
  }

  enableRetakeButton() {
    this.retakePhotoBtn.disabled = false;
  }

  disableRetakeButton() {
    this.retakePhotoBtn.disabled = true;
  }

  enableStartCameraButton() {
    this.startCameraBtn.disabled = false;
  }

  disableStartCameraButton() {
    this.startCameraBtn.disabled = true;
  }

  enableSubmitButton() {
    this.submitBtn.disabled = false;
  }

  disableSubmitButton() {
    this.submitBtn.disabled = true;
  }

  // File input UI methods
  clearFileInput() {
    this.photoFileInput.value = '';
    this.fileNameDisplay.textContent = 'No file chosen';
  }

  updateFileName(name) {
    this.fileNameDisplay.textContent = name;
  }

  // Photo preview methods
  showPhotoPreview(imageUrl) {
    this.photoPreview.innerHTML = `<img src="${imageUrl}" alt="Selected photo" class="preview-image">`;
    this.photoPreview.style.display = 'block';
  }

  hidePhotoPreview() {
    this.photoPreview.style.display = 'none';
  }

  // Message methods
  showErrorMessage(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.classList.remove('info', 'success');
    this.messageContainer.classList.add('error');
  }

  showInfoMessage(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.classList.remove('error', 'success');
    this.messageContainer.classList.add('info');
  }

  showSuccessMessage(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.classList.remove('error', 'info');
    this.messageContainer.classList.add('success');
  }

  // Location methods
  updateSelectedLocation(lat, lng) {
    this.selectedLocationText.textContent = `Selected location: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }

  showMapError(message) {
    this.mapContainer.innerHTML = `
      <div class="error-text">
        ${message}
      </div>
    `;
  }

  // Form methods
  getDescription() {
    return document.getElementById('description').value;
  }

  redirect(path) {
    window.location.hash = path;
  }
}
