// Menggunakan src/scripts/app.js

import routes from './routes/routes';
import Auth from './data/auth';
// import { getActiveRoute } from './routes/url-parser.js'; // Tidak digunakan di sini
import {
  isServiceWorkerAvailable,
  // setupSkipToContent, // Sudah ada di _setupNavigation
  // trantitionHelper, // Tidak terdefinisi, mungkin dari utils/view-transition.js
} from './utils';
import { 
  subscribePush, 
  unsubscribePush, 
  getSubscription,
  checkNotificationPermission,
  requestNotificationPermission,
} from './utils/push-notification';
// import {getAccessToken, getLogout} from './utils/view-transition.js'; // Tidak digunakan


class App {
  constructor({ content, navigationDrawer = null, drawerButton = null, skipLink = null }) {
    this.content = content;
    this.navigationDrawer = navigationDrawer;
    this.drawerButton = drawerButton;
    this.skipLink = skipLink;
    this.auth = new Auth();
    this.activePage = null;
    
    this._setupNavigation();
    this._setupPushNotificationButton(); // Panggil setup untuk tombol push notif
  }
  
  _setupNavigation() {
    if (this.drawerButton && this.navigationDrawer) {
      this.drawerButton.addEventListener('click', () => {
        this.navigationDrawer.classList.toggle('open');
      });

      document.body.addEventListener('click', (event) => {
        if (!this.navigationDrawer.contains(event.target) && !this.drawerButton.contains(event.target)) {
          this.navigationDrawer.classList.remove('open');
        }

        this.navigationDrawer.querySelectorAll('a, button.nav-button').forEach((linkOrButton) => {
          if (linkOrButton.contains(event.target)) {
            this.navigationDrawer.classList.remove('open');
          }
        });
      });
    }
    
    if (this.skipLink) {
      this.skipLink.addEventListener('click', (event) => {
        event.preventDefault();
        this.content.focus(); // Fokus ke main content
        // Atau jika ada elemen spesifik di dalam content:
        // const mainContentElement = this.content.querySelector('h1, [tabindex="-1"]');
        // if (mainContentElement) mainContentElement.focus();
      });
    }
    
    this._updateNavigation();
  }
  
  _updateNavigation() {
    const navList = document.querySelector('#nav-list');
    if (!navList) return;
    
    const isLoggedIn = this.auth.isUserLoggedIn();
    const pushNotificationMenuItem = document.getElementById('push-notification-menu-item');
    
    if (isLoggedIn) {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/saved">Saved Stories</a></li>
        <li><a href="#/stories/add">Add Story</a></li>
        <li><a href="#/about">About</a></li>
        <li id="push-notification-menu-item" style="display: none;"><button id="subscribePushNotification" class="nav-button" aria-label="Subscribe to notifications">🔔 Subscribe</button></li>
        <li><button id="logout-button" class="nav-button">Logout</button></li>
      `;
      
      setTimeout(() => { // Pastikan elemen sudah ada di DOM
        const logoutButton = document.getElementById('logout-button');
        if (logoutButton) {
          logoutButton.addEventListener('click', (event) => {
            event.preventDefault();
            this.auth.logout();
            this._updateNavigation(); // Update navigasi setelah logout
            window.location.hash = '#/';
            // window.location.reload(); // Tidak perlu reload jika _updateNavigation menangani UI dengan baik
          });
        }
        this._setupPushNotificationButton(); // Panggil lagi untuk memastikan event listener terpasang jika DOM di-render ulang
      }, 0); // 0 ms timeout untuk eksekusi setelah render cycle saat ini
    } else {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/login">Login</a></li>
        <li><a href="#/register">Register</a></li>
        <li><a href="#/about">About</a></li>
      `;
       if (pushNotificationMenuItem) pushNotificationMenuItem.style.display = 'none';
    }
  }

  async _setupPushNotificationButton() {
    if (!isServiceWorkerAvailable() || !('PushManager' in window)) {
      console.log('Push messaging is not supported');
      const pushMenuItem = document.getElementById('push-notification-menu-item');
      if (pushMenuItem) pushMenuItem.style.display = 'none';
      return;
    }

    if (!this.auth.isUserLoggedIn()) {
      const pushMenuItem = document.getElementById('push-notification-menu-item');
      if (pushMenuItem) pushMenuItem.style.display = 'none';
      return;
    }
    
    const pushMenuItem = document.getElementById('push-notification-menu-item');
    const subscribeButton = document.getElementById('subscribePushNotification');

    if (!pushMenuItem || !subscribeButton) {
      // Jika elemen belum ada (mungkin karena _updateNavigation belum selesai), coba lagi nanti
      // Ini bisa terjadi jika _setupPushNotificationButton dipanggil sebelum _updateNavigation
      // selesai me-render tombolnya.
      // Alternatifnya adalah memastikan _setupPushNotificationButton selalu dipanggil SETELAH
      // _updateNavigation selesai memperbarui DOM tombol tersebut.
      console.warn('Push notification button not found yet.');
      return;
    }
    
    pushMenuItem.style.display = 'list-item'; // Tampilkan item menu

    const updateButtonState = async () => {
      const currentSubscription = await getSubscription();
      if (currentSubscription) {
        subscribeButton.textContent = '🔕 Unsubscribe';
        subscribeButton.setAttribute('aria-label', 'Unsubscribe from notifications');
      } else {
        subscribeButton.textContent = '🔔 Subscribe';
        subscribeButton.setAttribute('aria-label', 'Subscribe to notifications');
      }
    };

    subscribeButton.removeEventListener('click', this.handleSubscribeButtonClick); // Hapus listener lama
    this.handleSubscribeButtonClick = async () => { // Simpan referensi handler
      const permission = await checkNotificationPermission();
      if (permission === 'denied') {
        alert('Notification permission is denied. Please allow notifications in your browser settings.');
        return;
      }
      if (permission === 'default') {
        const newPermission = await requestNotificationPermission();
        if (newPermission !== 'granted') {
          alert('Notification permission was not granted.');
          return;
        }
      }

      const currentSubscription = await getSubscription();
      if (currentSubscription) {
        await unsubscribePush();
      } else {
        await subscribePush();
      }
      await updateButtonState();
    };
    subscribeButton.addEventListener('click', this.handleSubscribeButtonClick);

    await updateButtonState();
  }


  async renderPage() {
    const hash = window.location.hash.slice(1);
    const url = hash || '/';
    
    console.log(`Rendering page for URL: ${url}`);
    
    const requiresAuth = url.startsWith('/stories/add') || url.startsWith('/story/');
    
    if (requiresAuth && !this.auth.isUserLoggedIn()) {
      console.log('Authentication required, redirecting to login');
      window.location.hash = '#/login';
      return;
    }
    
    let PageClass = null;
    PageClass = routes[url];
    
    if (!PageClass) {
      const urlParts = url.split('/');
      if (urlParts.length >= 3 && urlParts[1] === 'story') {
        const possibleRoute = '/story/:id';
        if (routes[possibleRoute]) {
          PageClass = routes[possibleRoute];
        }
      }
    }
    
    if (!PageClass) {
      console.warn(`No page found for route: ${url}, redirecting to home.`);
      window.location.hash = '#/';
      return;
    }
    
    try {
      this.activePage = new PageClass();
      console.log("Page instance created:", this.activePage);
      
      this._updateNavigation();
      await this._setupPushNotificationButton();
      
      const pageContent = await this.activePage.render();
      this.content.innerHTML = pageContent;
      
      if (typeof this.activePage.afterRender === 'function') {
        await this.activePage.afterRender();
      }
    } catch (error) {
      console.error('Error rendering page:', error);
      this.content.innerHTML = `<div class="container"><p>Error: ${error.message}</p></div>`;
    }
  }
}

export default App;