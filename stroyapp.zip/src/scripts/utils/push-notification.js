import CONFIG from '../config';
import Auth from '../data/auth'; // Untuk mendapatkan token

const auth = new Auth();

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

async function getSubscription() {
  const registration = await navigator.serviceWorker.ready;
  return registration.pushManager.getSubscription();
}

async function subscribePush() {
  try {
    const registration = await navigator.serviceWorker.ready;
    let subscription = await registration.pushManager.getSubscription();

    if (subscription) {
      console.log('User is already subscribed.');
      return subscription;
    }

    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(CONFIG.VAPID_PUBLIC_KEY),
    });

    console.log('User subscribed:', subscription);

    // Kirim subscription ke server
    const token = auth.getUserToken();
    if (token && subscription) {
      await sendSubscriptionToServer(subscription, token);
    }

    return subscription;
  } catch (error) {
    console.error('Failed to subscribe the user: ', error);
    if (Notification.permission === 'denied') {
      alert('Push notification permission was denied. Please enable it in your browser settings.');
    }
    throw error;
  }
}

async function unsubscribePush() {
  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();

    if (subscription) {
      const successful = await subscription.unsubscribe();
      if (successful) {
        console.log('User unsubscribed.');
        // Kirim info unsubscribe ke server
        const token = auth.getUserToken();
        if (token) {
          await sendUnsubscriptionToServer(subscription.endpoint, token);
        }
      } else {
        console.error('Failed to unsubscribe the user.');
      }
      return successful;
    }
    console.log('User was not subscribed.');
    return false;
  } catch (error) {
    console.error('Error unsubscribing user: ', error);
    throw error;
  }
}

async function sendSubscriptionToServer(subscription, token) {
  try {
    const response = await fetch(`${CONFIG.BASE_URL}/notifications/subscribe`, { //
      method: 'POST', //
      headers: {
        'Content-Type': 'application/json', //
        Authorization: `Bearer ${token}`, //
      },
      body: JSON.stringify({ //
        endpoint: subscription.endpoint, //
        keys: { //
          p256dh: subscription.toJSON().keys.p256dh, //
          auth: subscription.toJSON().keys.auth, //
        },
      }),
    });
    const responseData = await response.json();
    if (responseData.error) {
      console.error('Failed to send subscription to server:', responseData.message);
    } else {
      console.log('Subscription sent to server successfully.');
    }
  } catch (error) {
    console.error('Error sending subscription to server:', error);
  }
}

async function sendUnsubscriptionToServer(endpoint, token) {
  try {
    const response = await fetch(`${CONFIG.BASE_URL}/notifications/subscribe`, { //
      method: 'DELETE', //
      headers: {
        'Content-Type': 'application/json', //
        Authorization: `Bearer ${token}`, //
      },
      body: JSON.stringify({ endpoint }), //
    });
    const responseData = await response.json();
    if (responseData.error) {
      console.error('Failed to send unsubscription to server:', responseData.message);
    } else {
      console.log('Unsubscription sent to server successfully.');
    }
  } catch (error) {
    console.error('Error sending unsubscription to server:', error);
  }
}


async function checkNotificationPermission() {
    return Notification.permission;
}

async function requestNotificationPermission() {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
        console.warn('Notification permission not granted.');
    }
    return permission;
}

export {
  subscribePush,
  unsubscribePush,
  getSubscription,
  checkNotificationPermission,
  requestNotificationPermission,
};