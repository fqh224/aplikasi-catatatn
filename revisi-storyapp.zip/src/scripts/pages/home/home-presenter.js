import Story from '../../data/story'; //
import Auth from '../../data/auth'; //
import Map from '../../utils/map'; //

export default class HomePresenter {
  constructor({ view }) {
    this.view = view;
    this.story = new Story(); //
    this.auth = new Auth(); //
    this.map = null;
  }
  
  async init() {
    try {
      await this.initMap();
      await this.loadStories();
    } catch (error) {
      console.error('Error initializing HomePresenter:', error);
      this.view.showError('Failed to initialize page. Please try again later.');
    }
  }
  
  async initMap() {
    try {
      if (this.view.mapContainer) { // Pastikan mapContainer ada sebelum inisialisasi
        this.map = new Map({ mapElement: this.view.mapContainer }); //
        await this.map.initMap(); //
      } else {
        console.warn('Map container not found in HomeView.');
      }
    } catch (error) {
      console.error('Failed to initialize map:', error);
      if (this.view.mapContainer) {
        this.view.mapContainer.innerHTML = '<p class="error-text">Map could not be loaded.</p>';
      }
    }
  }
  
  async loadStories() {
    const isLoggedIn = this.auth.isUserLoggedIn();
    
    try {
      this.view.showLoading();
      
      let response;
      
      if (isLoggedIn) {
        console.log('Loading stories for logged-in user');
        response = await this.story.getStories({  
          location: 1, 
          size: 10 
        }); 
      } else {
        console.log('Loading guest stories for non-logged-in user');
        response = await this.story.getGuestStories({
          page: 1,
          size: 3
        });
      }
      
      if (response.error && (!response.listStory || response.listStory.length === 0)) {
        this.view.showError(response.message || 'Could not load stories.');
        return;
      }
      
      if (!response.listStory || response.listStory.length === 0) {
        this.view.showEmptyMessage();
        return;
      }
      
      // Show info message if data is from cache
      if (response.error && response.listStory && response.listStory.length > 0) {
         this.view.showInfoMessage('Displaying cached stories. Data might be outdated.');
      }

      // Show stories on map
      if (this.map && response.listStory.length > 0) {
        this.map.showStoriesOnMap(response.listStory);
      }
      
      // Display stories
      this.view.displayStories(response.listStory, isLoggedIn);
      
    } catch (error) {
      console.error('Error in loadStories:', error);
      this.view.showError(`Failed to load stories: ${error.message}. Please try again later.`);
    }
  }
}