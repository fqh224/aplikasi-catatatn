export function checkEnvironment() {
  console.log('=== Environment Verification ===');
  console.log(`Running in: ${process.env.NODE_ENV || 'unknown'} mode`);
  
  const mainContent = document.querySelector('#main-content');
  console.log('Main content element:', mainContent ? 'Found ✓' : 'Missing ✗');
  
  const navigationDrawer = document.querySelector('#navigation-drawer');
  console.log('Navigation drawer:', navigationDrawer ? 'Found ✓' : 'Missing ✗');
  
  console.log('Hash navigation supported:', 'onhashchange' in window ? 'Yes ✓' : 'No ✗');
  
  console.log('=== End Environment Check ===');
}
