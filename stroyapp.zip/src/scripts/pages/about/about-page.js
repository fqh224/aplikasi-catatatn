import { clearAllStoriesFromDB } from '../../data/indexed-db';

export default class AboutPage {
  async render() {
    console.log("Rendering About Page");
    return `
      <section class="container">
        <h1 class="section-title">About Faqih Story App</h1>
        <p>This application lets users share their stories with others.</p>
        <p>Built with JavaScript, Webpack, and the Dicoding Story API.</p>
        <button id="clearCacheButton" class="auth-button" style="margin-top: 20px; background-color: var(--error-color);">Clear Cached Stories</button>
        <p id="cacheMessage" class="form-message" style="margin-top: 10px;"></p>
      </section>
    `;
  }

  async afterRender() {
    console.log("About page afterRender executed");
    const clearCacheButton = document.getElementById('clearCacheButton');
    const cacheMessage = document.getElementById('cacheMessage');

    if (clearCacheButton) {
      clearCacheButton.addEventListener('click', async () => {
        try {
          await clearAllStoriesFromDB();
          cacheMessage.textContent = 'Cached stories cleared successfully!';
          cacheMessage.className = 'form-message success'; //
          console.log('All stories cleared from IndexedDB.');
        } catch (error) {
          cacheMessage.textContent = 'Failed to clear cached stories.';
          cacheMessage.className = 'form-message error'; //
          console.error('Error clearing stories from DB:', error);
        }
      });
    }
  }
}
