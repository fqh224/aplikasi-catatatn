import { login, register } from './api';
import CONFIG from '../config';

class Auth {
  constructor() {
    this._storage = localStorage;
    console.log('Auth initialized. User logged in:', this.isUserLoggedIn());
  }

  async login({ email, password }) {
    try {
      const response = await login({ email, password });
      
      if (!response.error) {
        const { token, name, userId } = response.loginResult;
        this._saveUserToken(token);
        this._saveUserData({ name, userId });
        console.log('Login successful for user:', name);
      } else {
        console.error('Login failed:', response.message);
      }
      
      return response;
    } catch (error) {
      console.error('Login error:', error);
      return { error: true, message: error.message };
    }
  }

  async register({ name, email, password }) {
    try {
      const response = await register({ name, email, password });
      console.log('Registration result:', response);
      return response;
    } catch (error) {
      console.error('Registration error:', error);
      return { error: true, message: error.message };
    }
  }

  logout() {
    this._storage.removeItem(CONFIG.STORAGE_KEY.TOKEN);
    this._storage.removeItem(CONFIG.STORAGE_KEY.USER);
    console.log('User logged out');
  }

  getUserToken() {
    const token = this._storage.getItem(CONFIG.STORAGE_KEY.TOKEN);
    return token;
  }

  getUserData() {
    const userDataString = this._storage.getItem(CONFIG.STORAGE_KEY.USER);
    if (!userDataString) return null;
    
    try {
      return JSON.parse(userDataString);
    } catch (error) {
      console.error('Error parsing user data:', error);
      return null;
    }
  }

  isUserLoggedIn() {
    const token = this.getUserToken();
    return Boolean(token);
  }

  _saveUserToken(token) {
    if (!token) {
      console.error('Attempted to save invalid token');
      return;
    }
    this._storage.setItem(CONFIG.STORAGE_KEY.TOKEN, token);
    console.log('Token saved successfully');
  }

  _saveUserData(data) {
    if (!data) {
      console.error('Attempted to save invalid user data');
      return;
    }
    this._storage.setItem(CONFIG.STORAGE_KEY.USER, JSON.stringify(data));
    console.log('User data saved successfully');
  }
}

export default Auth;
