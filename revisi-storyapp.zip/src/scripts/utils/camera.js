class Camera {
  constructor({ videoElement, canvasElement }) {
    this.videoElement = videoElement;
    this.canvasElement = canvasElement;
    this.stream = null;
  }

  async start() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      this.videoElement.srcObject = this.stream;
    } catch (error) {
      console.error('Error starting camera:', error);
      throw new Error('Failed to start camera');
    }
  }

  stop() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
      this.videoElement.srcObject = null;
    }
  }

  takePicture() {
    const context = this.canvasElement.getContext('2d');
    const { videoWidth, videoHeight } = this.videoElement;
    
    this.canvasElement.width = videoWidth;
    this.canvasElement.height = videoHeight;
    
    context.drawImage(this.videoElement, 0, 0, videoWidth, videoHeight);
    
    return new Promise((resolve) => {
      this.canvasElement.toBlob(
        (blob) => {
          const file = new File([blob], 'picture.jpg', { type: 'image/jpeg' });
          resolve(file);
        },
        'image/jpeg',
        0.95
      );
    });
  }
}

export default Camera;
