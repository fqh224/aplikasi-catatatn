import LoginView from './login-view';
import LoginPresenter from './login-presenter';

export default class LoginPage {
  constructor() {
    this.view = new LoginView();
    this.presenter = null;
  }

  async render() {
    // Create presenter here to check if user is logged in
    this.presenter = new LoginPresenter({ 
      view: this.view 
    });
    
    if (this.presenter.checkLoggedIn()) {
      window.location.hash = '#/';
      return '';
    }

    return this.view.getTemplate();
  }

  async afterRender() {
    this.view.initElements();
    
    // Initialize the presenter
    await this.presenter.init();
  }
}
