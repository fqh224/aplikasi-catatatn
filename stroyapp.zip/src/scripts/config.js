const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  STORAGE_KEY: {
    TOKEN: 'story_app_token',
    USER: 'story_app_user',
  },
  DEFAULT_LANGUAGE: 'id',
  MAP_KEY: 'YOUR_MAP_KEY_HERE', // Ganti jika Anda menggunakan map key spesifik
  VAPID_PUBLIC_KEY: 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk', //
  CACHE_NAME: 'storyapp-cache-v1',
  DATABASE_NAME: 'story-app-database',
  OBJECT_STORE_NAME: 'stories',
};

export default CONFIG;