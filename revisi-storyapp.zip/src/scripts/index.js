import '../styles/styles.css';
import App from './app'; 
import { checkEnvironment } from './utils/verify-setup';
import { isServiceWorkerAvailable, registerServiceWorker } from './utils'; // Impor fungsi SW

document.addEventListener('DOMContentLoaded', async () => {
  console.log('App initialization started');
  checkEnvironment();
  
  try {
    const mainContent = document.querySelector('#main-content');
    const navigationDrawer = document.querySelector('#navigation-drawer');
    const drawerButton = document.querySelector('#drawer-button');
    const skipLink = document.querySelector('#skip-link');
    
    if (!mainContent) {
      console.error('Could not find #main-content element');
      document.body.innerHTML = '<p>Error: Could not find main content container</p>';
      return;
    }
    
    // mainContent.innerHTML = '<div class="container"><p>JavaScript is running. Setting up the application...</p></div>';
    
    const app = new App({
      content: mainContent,
      navigationDrawer,
      drawerButton,
      skipLink
    });
    
    // Daftarkan Service Worker
    if (isServiceWorkerAvailable()) {
      await registerServiceWorker();

      console.log('Berhasil mendaftarkan service worker.');
    }
    
    await app.renderPage(); // Render halaman awal
    
    window.addEventListener('hashchange', async () => {
      console.log('Hash changed to:', window.location.hash);
      await app.renderPage();
    });
    
    console.log('App initialization completed');
  } catch (error) {
    console.error('Fatal error during app initialization:', error);
    document.body.innerHTML = `<p>Fatal error: ${error.message}</p>`;
  }
});