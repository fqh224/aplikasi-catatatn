const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
  entry: {
    app: path.resolve(__dirname, 'src/scripts/index.js'),
    //sw: path.resolve(__dirname, 'src/scripts/sw.js'), // Pastikan sw.js menjadi entry point
  },
  output: {
    filename: '[name].bundle.js', // Akan menghasilkan app.bundle.js dan sw.bundle.js
    path: path.resolve(__dirname, 'dist'),
    clean: true, // Membersihkan direktori dist sebelum build
  },
  module: {
    rules: [
      {
        test: /\.(png|jpe?g|gif|svg)$/i, // Menambahkan svg untuk ikon
        type: 'asset/resource',
        generator: {
          filename: 'assets/images/[hash][ext][query]',
        },
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'src/index.html'),
      chunks: ['app'], // Hanya memasukkan app.bundle.js ke HTML
      filename: 'index.html',
    }),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: path.resolve(__dirname, 'src/public/'),
          to: path.resolve(__dirname, 'dist/'),
          globOptions: {
            // Mengabaikan file yang mungkin tidak ingin Anda salin secara langsung jika ada
            // ignore: ['**/index.html'], // HtmlWebpackPlugin sudah menangani ini
          },
        },
      ],
    }),
  ],
};