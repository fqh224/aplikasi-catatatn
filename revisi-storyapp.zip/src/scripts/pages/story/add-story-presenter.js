// Presenter for Add Story page
import Story from '../../data/story';
import Auth from '../../data/auth';
import Camera from '../../utils/camera';
import Map from '../../utils/map';

export default class AddStoryPresenter {
  constructor({ view }) {
    this.view = view;
    this.story = new Story();
    this.auth = new Auth();
    this.camera = null;
    this.map = null;
    this.photoFile = null;
    this.currentLocation = { lat: null, lng: null };
  }

  async init() {
    try {
      await this.initMap();
      this.initCamera();
      this.attachEventListeners();
    } catch (error) {
      console.error('Error initializing presenter:', error);
    }
  }

  async initMap() {
    try {
      this.map = new Map({
        mapElement: this.view.mapContainer,
        onLocationPicked: (lat, lng) => {
          this.currentLocation = { lat, lng };
          this.view.updateSelectedLocation(lat, lng);
        }
      });
      await this.map.initMap();
    } catch (error) {
      console.error('Failed to initialize map:', error);
      this.view.showMapError('Failed to initialize map. You can still submit your story without location.');
    }
  }

  initCamera() {
    this.camera = new Camera({
      videoElement: this.view.cameraPreview,
      canvasElement: this.view.photoCanvas,
    });
  }

  attachEventListeners() {
    this.view.registerCameraStartHandler(this.handleStartCamera.bind(this));
    this.view.registerTakePhotoHandler(this.handleTakePhoto.bind(this));
    this.view.registerRetakePhotoHandler(this.handleRetakePhoto.bind(this));
    this.view.registerFileInputHandler(this.handleFileInput.bind(this));
    this.view.registerFormSubmitHandler(this.handleFormSubmit.bind(this));
    this.view.registerHashChangeHandler(this.handleHashChange.bind(this));
  }

  async handleStartCamera() {
    try {
      await this.camera.start();
      this.view.showCameraPreview();
      this.view.enableTakePhotoButton();
      this.view.disableStartCameraButton();
      this.view.clearFileInput();
    } catch (error) {
      this.view.showErrorMessage('Failed to start camera: ' + error.message);
    }
  }

  async handleTakePhoto() {
    try {
      this.photoFile = await this.camera.takePicture();
      this.camera.stop();
      
      this.view.hideCameraPreview();
      this.view.showPhotoPreview(URL.createObjectURL(this.photoFile));
      this.view.enableRetakeButton();
      this.view.disableTakePhotoButton();
      this.view.enableStartCameraButton();
      this.view.enableSubmitButton();
    } catch (error) {
      this.view.showErrorMessage('Failed to take photo: ' + error.message);
    }
  }

  async handleRetakePhoto() {
    try {
      this.photoFile = null;
      this.view.hidePhotoPreview();
      this.view.disableRetakeButton();
      this.view.disableSubmitButton();
      
      await this.camera.start();
      this.view.showCameraPreview();
      this.view.enableTakePhotoButton();
      this.view.disableStartCameraButton();
    } catch (error) {
      this.view.showErrorMessage('Failed to restart camera: ' + error.message);
    }
  }

  handleFileInput(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    this.view.updateFileName(file.name);

    if (this.camera && this.camera.stream) {
      this.camera.stop();
      this.view.enableStartCameraButton();
      this.view.disableTakePhotoButton();
    }
    
    this.photoFile = file;
    this.view.showPhotoPreview(URL.createObjectURL(file));
    this.view.enableSubmitButton();
  }

  async handleFormSubmit(event) {
    event.preventDefault();
    
    if (!this.photoFile) {
      this.view.showErrorMessage('Please take or upload a photo');
      return;
    }
    
    const description = this.view.getDescription();
    
    this.view.showInfoMessage('Uploading your story...');
    this.view.disableSubmitButton();
    
    try {
      const storyData = {
        description,
        photo: this.photoFile,
      };
      
      if (this.currentLocation.lat && this.currentLocation.lng) {
        storyData.lat = this.currentLocation.lat;
        storyData.lon = this.currentLocation.lng;
      }
      
      const response = await this.story.addStory(storyData);
      
      if (response.error) {
        this.view.showErrorMessage(response.message);
        this.view.enableSubmitButton();
      } else {
        this.view.showSuccessMessage('Story shared successfully!');
        
        if (this.camera) {
          this.camera.stop();
        }
        
        setTimeout(() => {
          this.view.redirect('#/');
        }, 1500);
      }
    } catch (error) {
      console.error(error);
      this.view.showErrorMessage('Failed to upload story: ' + error.message);
      this.view.enableSubmitButton();
    }
  }

  handleHashChange() {
    if (this.camera) {
      this.camera.stop();
    }
  }
}
