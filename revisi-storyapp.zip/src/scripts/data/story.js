import { getStories as fetchStories, getStoryById as fetchStoryById, addStory } from './api'; //
import Auth from './auth';
import {
  getAllStoriesFromDB,
  getStoryByIdFromDB,
  putStoryToDB,
  putMultipleStoriesToDB,
} from './indexed-db';

class Story {
  constructor() {
    this.auth = new Auth();
  }

  async getStories({ page = 1, size = 10, location = 0 } = {}) {
    const token = this.auth.getUserToken();
    const isLoggedIn = this.auth.isUserLoggedIn();
    
    if (!isLoggedIn || !token) {
      console.log('User not logged in, fetching guest stories');
      return this.getGuestStories({ page, size });
    }

    try {
      console.log('Fetching stories from API with token');
      const apiResponse = await fetchStories({ token, page, size, location });

      if (!apiResponse.error && apiResponse.listStory) {
        await putMultipleStoriesToDB(apiResponse.listStory);
        console.log('Stories fetched from API and cached in IndexedDB');
      }
      return apiResponse;
    } catch (error) {
      console.warn('API fetch failed for stories, trying IndexedDB. Error:', error);
      try {
        const cachedStories = await getAllStoriesFromDB();
        if (cachedStories && cachedStories.length > 0) {
          console.log('Stories fetched from IndexedDB');
          const startIndex = (page - 1) * size;
          const endIndex = startIndex + size;
          const paginatedStories = cachedStories.slice(startIndex, endIndex);
          return { error: true, message: 'Showing cached data', listStory: paginatedStories };
        }
        console.warn('No stories found in IndexedDB cache.');
        return { error: true, message: 'Failed to fetch stories from API and cache.', listStory: [] };
      } catch (dbError) {
        console.error('Error fetching stories from IndexedDB:', dbError);
        return { error: true, message: `Network and cache error: ${dbError.message}`, listStory: [] };
      }
    }
  }

  async getStoryById(id) {
    const token = this.auth.getUserToken();
    const isLoggedIn = this.auth.isUserLoggedIn();
    
    if (!isLoggedIn || !token) {
      console.warn('Attempted to get story by ID without authentication');
      return { error: true, message: 'Authentication required to view story details' };
    }

    try {
      const apiResponse = await fetchStoryById({ id, token });
      if (!apiResponse.error && apiResponse.story) {
        await putStoryToDB(apiResponse.story);
        console.log(`Story ${id} fetched from API and cached.`);
      }
      return apiResponse;
    } catch (error) {
      console.warn(`API fetch failed for story ${id}, trying IndexedDB. Error:`, error);
      try {
        const cachedStory = await getStoryByIdFromDB(id);
        if (cachedStory) {
          console.log(`Story ${id} fetched from IndexedDB.`);
          return { error: false, message: 'Story fetched from cache', story: cachedStory };
        }
        console.warn(`Story ${id} not found in IndexedDB cache.`);
        return { error: true, message: 'Failed to fetch story from API and cache.' };
      } catch (dbError) {
        console.error(`Error fetching story ${id} from IndexedDB:`, dbError);
        return { error: true, message: `Network and cache error for story ${id}: ${dbError.message}` };
      }
    }
  }

  async addStory({ description, photo, lat, lon }) {
    const token = this.auth.getUserToken(); //
    if (!token) {
      return { error: true, message: 'Authentication required to add stories' };
    }
    // Untuk addStory, kita asumsikan harus online.
    // Fungsionalitas offline sync untuk 'add' lebih kompleks dan di luar cakupan saat ini.
    try {
      return await addStory({ description, photo, lat, lon, token }); //
    } catch (error) {
      console.error('Error adding story via API:', error);
      return { error: true, message: `Failed to add story: ${error.message}` };
    }
  }
  
  async getGuestStories({ page = 1, size = 3 }) { //
    // Implementasi getGuestStories tetap sama seperti sebelumnya
    const testStories = [
      {
        id: 'guest-story-1',
        name: 'John Doe',
        description: 'This is a sample story for guest users. Login to see more stories and details!',
        photoUrl: 'https://source.unsplash.com/400x300/?nature',
        createdAt: new Date().toISOString(),
        lat: -6.175,
        lon: 106.827
      },
      {
        id: 'guest-story-2',
        name: 'Jane Smith',
        description: 'Another interesting story that you can view if you are a guest. Sign up to contribute your own!',
        photoUrl: 'https://source.unsplash.com/400x300/?travel',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        lat: -6.2,
        lon: 106.8
      },
      {
        id: 'guest-story-3',
        name: 'Alex Johnson',
        description: 'The final sample story in our guest preview. Create an account to access all features!',
        photoUrl: 'https://source.unsplash.com/400x300/?city',
        createdAt: new Date(Date.now() - 172800000).toISOString(),
        lat: -6.18,
        lon: 106.84
      }
    ];

    const startIndex = (page - 1) * size;
    const selectedStories = testStories.slice(startIndex, startIndex + size);
    
    // Simulasi network delay
    await new Promise(resolve => setTimeout(resolve, 300)); 
    
    return {
      error: false,
      message: 'Stories fetched successfully (guest preview)',
      listStory: selectedStories
    };
  }
}

export default Story;