const isViewTransitionSupported = () => Boolean(document.startViewTransition);

const updateTheDOMCallback = (callback) => {
  if (isViewTransitionSupported()) {
    document.startViewTransition(() => {
      callback();
    });
  } else {
    callback();
  }
};

export { isViewTransitionSupported, updateTheDOMCallback };
