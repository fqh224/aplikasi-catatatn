import CONFIG from '../config';

const { DATABASE_NAME, OBJECT_STORE_NAME } = CONFIG;
const SAVED_STORIES_STORE = 'saved-stories';
const DB_VERSION = 2; // Increment version for new object store

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DB_VERSION);

    request.onerror = (event) => {
      console.error('IndexedDB error:', event.target.errorCode);
      reject(new Error(`IndexedDB error: ${event.target.errorCode}`));
    };

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      
      // Create stories object store
      if (!db.objectStoreNames.contains(OBJECT_STORE_NAME)) {
        const objectStore = db.createObjectStore(OBJECT_STORE_NAME, { keyPath: 'id' });
        objectStore.createIndex('name', 'name', { unique: false });
        console.log(`Object store ${OBJECT_STORE_NAME} created.`);
      }
      
      // Create saved stories object store
      if (!db.objectStoreNames.contains(SAVED_STORIES_STORE)) {
        const savedStoriesStore = db.createObjectStore(SAVED_STORIES_STORE, { keyPath: 'id' });
        savedStoriesStore.createIndex('savedAt', 'savedAt', { unique: false });
        console.log(`Object store ${SAVED_STORIES_STORE} created.`);
      }
    };

    request.onsuccess = (event) => {
      console.log('Database opened successfully');
      resolve(event.target.result);
    };
  });
}

async function getAllStoriesFromDB() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readonly');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error('Error fetching all stories from DB:', event.target.errorCode);
      reject(new Error(`Error fetching all stories from DB: ${event.target.errorCode}`));
    };
  });
}

async function getStoryByIdFromDB(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readonly');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    const request = store.get(id);

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error fetching story ${id} from DB:`, event.target.errorCode);
      reject(new Error(`Error fetching story ${id} from DB: ${event.target.errorCode}`));
    };
  });
}

async function putStoryToDB(story) {
  if (!story || !story.id) {
    console.error('Invalid story object provided to putStoryToDB');
    return Promise.reject(new Error('Invalid story object'));
  }
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    const request = store.put(story);

    request.onsuccess = () => {
      console.log(`Story ${story.id} added/updated in DB`);
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error putting story ${story.id} to DB:`, event.target.errorCode);
      reject(new Error(`Error putting story ${story.id} to DB: ${event.target.errorCode}`));
    };
  });
}

async function putMultipleStoriesToDB(stories) {
  if (!Array.isArray(stories)) {
     console.error('Invalid stories array provided to putMultipleStoriesToDB');
    return Promise.reject(new Error('Stories must be an array'));
  }
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    let completedOperations = 0;

    stories.forEach((story) => {
      if (story && story.id) {
        const request = store.put(story);
        request.onsuccess = () => {
          completedOperations++;
          if (completedOperations === stories.length) {
            console.log('All stories processed for DB update.');
            resolve();
          }
        };
        request.onerror = (event) => {
          console.error(`Error putting story ${story.id} to DB:`, event.target.errorCode);
          // Don't reject immediately, try to process other stories
        };
      } else {
        console.warn('Skipping invalid story object during bulk put:', story);
        completedOperations++; // Count it as processed to not hang the promise
         if (completedOperations === stories.length) {
            resolve();
          }
      }
    });
    if (stories.length === 0) {
        resolve(); // Resolve if no stories to process
    }
  });
}


async function deleteStoryFromDB(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => {
      console.log(`Story ${id} deleted from DB`);
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error deleting story ${id} from DB:`, event.target.errorCode);
      reject(new Error(`Error deleting story ${id} from DB: ${event.target.errorCode}`));
    };
  });
}

async function clearAllStoriesFromDB() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(OBJECT_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(OBJECT_STORE_NAME);
    const request = store.clear();

    request.onsuccess = () => {
      console.log('All stories cleared from DB');
      resolve();
    };

    request.onerror = (event) => {
      console.error('Error clearing stories from DB:', event.target.errorCode);
      reject(new Error(`Error clearing stories from DB: ${event.target.errorCode}`));
    };
  });
}

// Saved Stories functions
async function saveStoryToDB(story) {
  if (!story || !story.id) {
    console.error('Invalid story object provided to saveStoryToDB');
    return Promise.reject(new Error('Invalid story object'));
  }
  
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVED_STORIES_STORE, 'readwrite');
    const store = transaction.objectStore(SAVED_STORIES_STORE);
    
    const savedStory = {
      ...story,
      savedAt: new Date().toISOString()
    };
    
    const request = store.put(savedStory);

    request.onsuccess = () => {
      console.log(`Story ${story.id} saved to favorites`);
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error saving story ${story.id}:`, event.target.errorCode);
      reject(new Error(`Error saving story ${story.id}: ${event.target.errorCode}`));
    };
  });
}

async function removeSavedStoryFromDB(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVED_STORIES_STORE, 'readwrite');
    const store = transaction.objectStore(SAVED_STORIES_STORE);
    const request = store.delete(id);

    request.onsuccess = () => {
      console.log(`Saved story ${id} removed`);
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error removing saved story ${id}:`, event.target.errorCode);
      reject(new Error(`Error removing saved story ${id}: ${event.target.errorCode}`));
    };
  });
}

async function getAllSavedStoriesFromDB() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVED_STORIES_STORE, 'readonly');
    const store = transaction.objectStore(SAVED_STORIES_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error('Error fetching saved stories:', event.target.errorCode);
      reject(new Error(`Error fetching saved stories: ${event.target.errorCode}`));
    };
  });
}

async function getSavedStoryFromDB(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVED_STORIES_STORE, 'readonly');
    const store = transaction.objectStore(SAVED_STORIES_STORE);
    const request = store.get(id);

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = (event) => {
      console.error(`Error fetching saved story ${id}:`, event.target.errorCode);
      reject(new Error(`Error fetching saved story ${id}: ${event.target.errorCode}`));
    };
  });
}

async function clearAllSavedStoriesFromDB() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVED_STORIES_STORE, 'readwrite');
    const store = transaction.objectStore(SAVED_STORIES_STORE);
    const request = store.clear();

    request.onsuccess = () => {
      console.log('All saved stories cleared');
      resolve();
    };

    request.onerror = (event) => {
      console.error('Error clearing saved stories:', event.target.errorCode);
      reject(new Error(`Error clearing saved stories: ${event.target.errorCode}`));
    };
  });
}

export {
  openDB,
  getAllStoriesFromDB,
  getStoryByIdFromDB,
  putStoryToDB,
  putMultipleStoriesToDB,
  deleteStoryFromDB,
  clearAllStoriesFromDB,
  saveStoryToDB,
  removeSavedStoryFromDB,
  getAllSavedStoriesFromDB,
  getSavedStoryFromDB,
  clearAllSavedStoriesFromDB,
};