import RegisterView from './register-view';
import RegisterPresenter from './register-presenter';

export default class RegisterPage {
  constructor() {
    this.view = new RegisterView();
    this.presenter = null;
  }

  async render() {
    // Create presenter here to check if user is logged in
    this.presenter = new RegisterPresenter({
      view: this.view
    });
    
    if (this.presenter.checkLoggedIn()) {
      window.location.hash = '#/';
      return '';
    }

    return this.view.getTemplate();
  }

  async afterRender() {
    this.view.initElements();
    
    // Initialize the presenter
    await this.presenter.init();
  }
}
