import StoryDetailView from './story-detail-view';
import StoryDetailPresenter from './story-detail-presenter';

export default class StoryDetailPage {
  constructor() {
    this.view = new StoryDetailView();
    this.presenter = null;
  }

  async render() {
    return this.view.getTemplate();
  }

  async afterRender() {
    this.view.initElements();
    
    // Initialize the presenter with the view
    this.presenter = new StoryDetailPresenter({
      view: this.view
    });
    
    // Initialize the presenter
    await this.presenter.init();
  }
}
