import { showFormattedDate } from '../../utils/index';

export default class SavedStoriesView {
  constructor() {
    this.savedStoriesContainer = null;
    this.searchInput = null;
    this.sortSelect = null;
    this.clearAllBtn = null;
  }

  getTemplate() {
    return `
      <section class="container">
        <h1 class="section-title">Saved Stories</h1>
        
        <div class="saved-stories-controls">
          <div class="search-container">
            <input type="text" id="searchStories" class="search-input" placeholder="Search saved stories...">
          </div>
          <div class="sort-container">
            <select id="sortStories" class="sort-select">
              <option value="savedAt-desc">Recently Saved</option>
              <option value="savedAt-asc">Oldest Saved</option>
              <option value="name-asc">Name A-Z</option>
              <option value="name-desc">Name Z-A</option>
            </select>
          </div>
          <button id="clearAllBtn" class="clear-all-button">Clear All</button>
        </div>
        
        <div id="savedStoriesContainer" class="saved-stories-container">
          <p class="loading-text">Loading saved stories...</p>
        </div>
      </section>
    `;
  }

  initElements() {
    this.savedStoriesContainer = document.getElementById('savedStoriesContainer');
    this.searchInput = document.getElementById('searchStories');
    this.sortSelect = document.getElementById('sortStories');
    this.clearAllBtn = document.getElementById('clearAllBtn');
  }

  showLoading() {
    this.savedStoriesContainer.innerHTML = '<p class="loading-text">Loading saved stories...</p>';
  }

  showError(message) {
    this.savedStoriesContainer.innerHTML = `<p class="error-text">${message}</p>`;
  }

  showEmptyMessage() {
    this.savedStoriesContainer.innerHTML = `
      <div class="empty-saved-stories">
        <h2>No saved stories yet</h2>
        <p>Start exploring stories and save your favorites!</p>
        <a href="#/" class="action-button">Browse Stories</a>
      </div>
    `;
  }

  displaySavedStories(stories) {
    if (!stories || stories.length === 0) {
      this.showEmptyMessage();
      return;
    }

    this.savedStoriesContainer.innerHTML = '';
    
    stories.forEach(story => {
      const storyCard = this.createSavedStoryCard(story);
      this.savedStoriesContainer.appendChild(storyCard);
    });
  }

  createSavedStoryCard(story) {
    const cardElement = document.createElement('article');
    cardElement.className = 'saved-story-card';
    cardElement.innerHTML = `
      <div class="saved-story-image-container">
        <img src="${story.photoUrl}" alt="${story.name}'s story" class="saved-story-image" loading="lazy">
      </div>
      <div class="saved-story-content">
        <h3 class="saved-story-title">${story.name}</h3>
        <p class="saved-story-date">Created: ${showFormattedDate(story.createdAt)}</p>
        <p class="saved-story-saved-date">★ Saved: ${showFormattedDate(story.savedAt)}</p>
        <p class="saved-story-description">${story.description}</p>
        ${story.lat && story.lon ? `<p class="saved-story-location">📍 Location: ${story.lat.toFixed(2)}, ${story.lon.toFixed(2)}</p>` : ''}
        
        <div class="saved-story-actions">
          <a href="#/story/${story.id}" class="action-button view-button">
            <span>👁</span> View Details
          </a>
          <button class="action-button remove-button" data-story-id="${story.id}">
            <span>🗑</span> Remove
          </button>
        </div>
      </div>
    `;
    
    return cardElement;
  }

  registerSearchHandler(handler) {
    this.searchInput.addEventListener('input', handler);
  }

  registerSortHandler(handler) {
    this.sortSelect.addEventListener('change', handler);
  }

  registerClearAllHandler(handler) {
    this.clearAllBtn.addEventListener('click', handler);
  }

  registerRemoveStoryHandler(handler) {
    this.savedStoriesContainer.addEventListener('click', (event) => {
      if (event.target.classList.contains('remove-button')) {
        const storyId = event.target.getAttribute('data-story-id');
        handler(storyId, event.target.closest('.saved-story-card'));
      }
    });
  }

  getSearchQuery() {
    return this.searchInput.value.toLowerCase();
  }

  getSortOption() {
    return this.sortSelect.value;
  }

  showSuccessMessage(message) {
    // Create toast instead of inline message
    this.showToast(message, 'success');
  }

  showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = this.getToastIcon(type);
    
    toast.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span>${message}</span>
      <button class="toast-close">&times;</button>
    `;

    // Add to container
    toastContainer.appendChild(toast);

    // Show toast
    setTimeout(() => {
      toast.classList.add('show');
    }, 100);

    // Auto remove after 3 seconds
    setTimeout(() => {
      this.removeToast(toast);
    }, 3000);

    // Close button handler
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
      this.removeToast(toast);
    });
  }

  getToastIcon(type) {
    switch (type) {
      case 'success': return '✓';
      case 'error': return '✕';
      case 'info': return 'ℹ';
      default: return 'ℹ';
    }
  }

  removeToast(toast) {
    toast.classList.remove('show');
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }

  showConfirmDialog(message) {
    return confirm(message);
  }
}
