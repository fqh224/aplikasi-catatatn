import CONFIG from '../config';

const ENDPOINTS = {
  REGISTER: `${CONFIG.BASE_URL}/register`,
  LOGIN: `${CONFIG.BASE_URL}/login`,
  GET_STORIES: `${CONFIG.BASE_URL}/stories`,
  ADD_STORY: `${CONFIG.BASE_URL}/stories`,
  ADD_GUEST_STORY: `${CONFIG.BASE_URL}/stories/guest`,
  DETAIL_STORY: (id) => `${CONFIG.BASE_URL}/stories/${id}`,
};

export async function register({ name, email, password }) {
  try {
    const response = await fetch(ENDPOINTS.REGISTER, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, password }),
    });
    
    return await response.json();
  } catch (error) {
    console.error('Register error:', error);
    return { error: true, message: error.message };
  }
}

export async function login({ email, password }) {
  try {
    const response = await fetch(ENDPOINTS.LOGIN, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
    
    return await response.json();
  } catch (error) {
    console.error('Login error:', error);
    return { error: true, message: error.message };
  }
}

export async function getStories({ token, page = 1, size = 10, location = 0 }) {
  try {
    const url = new URL(ENDPOINTS.GET_STORIES);
    url.searchParams.append('page', page);
    url.searchParams.append('size', size);
    url.searchParams.append('location', location);
    
    console.log('Fetching stories with token:', token ? 'Valid token' : 'No token');
    console.log('Request URL:', url.toString());
    
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    
    const result = await response.json();
    
    console.log('Stories API response:', result);
    
    return result;
  } catch (error) {
    console.error('Error fetching stories:', error);
    return { error: true, message: error.message };
  }
}

export async function getStoryById({ id, token }) {
  try {
    const response = await fetch(ENDPOINTS.DETAIL_STORY(id), {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching story details:', error);
    return { error: true, message: error.message };
  }
}

export async function addStory({ description, photo, lat, lon, token }) {
  try {
    const formData = new FormData();
    formData.append('description', description);
    formData.append('photo', photo);
    
    if (lat) formData.append('lat', lat);
    if (lon) formData.append('lon', lon);
  
    const response = await fetch(ENDPOINTS.ADD_STORY, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });
    
    return await response.json();
  } catch (error) {
    console.error('Error adding story:', error);
    return { error: true, message: error.message };
  }
}

export async function addGuestStory({ description, photo, lat, lon }) {
  try {
    const formData = new FormData();
    formData.append('description', description);
    formData.append('photo', photo);
    
    if (lat) formData.append('lat', lat);
    if (lon) formData.append('lon', lon);
  
    const response = await fetch(ENDPOINTS.ADD_GUEST_STORY, {
      method: 'POST',
      body: formData,
    });
    
    return await response.json();
  } catch (error) {
    console.error('Error adding guest story:', error);
    return { error: true, message: error.message };
  }
}

export async function getGuestStories({ page = 1, size = 10, location = 0 }) {
  try {
    const testStories = [
      {
        id: 'guest-story-1',
        name: 'John Doe',
        description: 'This is a sample story for guest users. Login to see more stories and details!',
        photoUrl: 'https://source.unsplash.com/400x300/?nature',
        createdAt: new Date().toISOString(),
        lat: -6.175,
        lon: 106.827
      },
      {
        id: 'guest-story-2',
        name: 'Jane Smith',
        description: 'Another interesting story that you can view if you are a guest. Sign up to contribute your own!',
        photoUrl: 'https://source.unsplash.com/400x300/?travel',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        lat: -6.2,
        lon: 106.8
      },
      {
        id: 'guest-story-3',
        name: 'Alex Johnson',
        description: 'The final sample story in our guest preview. Create an account to access all features!',
        photoUrl: 'https://source.unsplash.com/400x300/?city',
        createdAt: new Date(Date.now() - 172800000).toISOString(),
        lat: -6.18,
        lon: 106.84
      }
    ];
    
    const startIndex = (page - 1) * size;
    const selectedStories = testStories.slice(startIndex, startIndex + size);
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      error: false,
      message: 'Stories fetched successfully (guest preview)',
      listStory: selectedStories
    };
  } catch (error) {
    console.error('Error getting guest stories:', error);
    return { error: true, message: error.message };
  }
}