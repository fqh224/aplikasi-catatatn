// View for Login page
export default class LoginView {
  constructor() {
    this.loginForm = null;
    this.messageContainer = null;
  }

  getTemplate() {
    return `
      <section class="container auth-container">
        <h1 class="auth-title">Login</h1>
        <form id="loginForm" class="auth-form">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required placeholder="example@email.com">
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required minlength="8" placeholder="Minimum 8 characters">
          </div>
          <div id="loginMessage" class="form-message"></div>
          <button type="submit" class="auth-button">Login</button>
          <p class="auth-redirect">
            Don't have an account? <a href="#/register">Register here</a>
          </p>
        </form>
      </section>
    `;
  }

  initElements() {
    this.loginForm = document.getElementById('loginForm');
    this.messageContainer = document.getElementById('loginMessage');
  }

  registerFormSubmitHandler(handler) {
    this.loginForm.addEventListener('submit', handler);
  }

  getFormValues() {
    return {
      email: document.getElementById('email').value,
      password: document.getElementById('password').value
    };
  }

  showLoading() {
    this.messageContainer.textContent = 'Logging in...';
    this.messageContainer.classList.remove('error');
    this.messageContainer.classList.add('info');
  }

  showError(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.classList.remove('info', 'success');
    this.messageContainer.classList.add('error');
  }

  showSuccess(message) {
    this.messageContainer.textContent = message || 'Login successful! Redirecting...';
    this.messageContainer.classList.remove('error', 'info');
    this.messageContainer.classList.add('success');
  }

  redirect(path) {
    setTimeout(() => {
      window.location.hash = path;
    }, 1000);
  }
}
