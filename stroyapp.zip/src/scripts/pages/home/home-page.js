import HomeView from './home-view';
import HomePresenter from './home-presenter';

export default class HomePage {
  constructor() {
    this.view = new HomeView();
    this.presenter = null;
  }

  async render() {
    return this.view.getTemplate();
  }

  async afterRender() {
    this.view.initElements();
    
    // Initialize the presenter with the view
    this.presenter = new HomePresenter({
      view: this.view
    });
    
    // Initialize the presenter
    await this.presenter.init();
  }
}
