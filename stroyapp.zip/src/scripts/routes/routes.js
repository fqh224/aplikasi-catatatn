import HomePage from '../pages/home/home-page';
import AboutPage from '../pages/about/about-page';
import LoginPage from '../pages/auth/login-page';
import RegisterPage from '../pages/auth/register-page';
import StoryDetailPage from '../pages/story/story-detail-page';
import AddStoryPage from '../pages/story/add-story-page';
import SavedStoriesPage from '../pages/saved-stories/saved-stories-page';

const routes = {
  '/': HomePage,
  '/about': AboutPage,
  '/login': LoginPage,
  '/register': RegisterPage,
  '/story/:id': StoryDetailPage,
  '/stories/add': AddStoryPage,
  '/saved': SavedStoriesPage,
};

export default routes;
