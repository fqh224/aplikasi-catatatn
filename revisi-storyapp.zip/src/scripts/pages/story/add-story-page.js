import AddStoryView from './add-story-view';
import AddStoryPresenter from './add-story-presenter';

export default class AddStoryPage {
  constructor() {
    this.view = new AddStoryView();
    this.presenter = null;
  }

  async render() {
    return this.view.getTemplate();
  }
  async afterRender() {
    this.view.initElements();
    
    // Initialize the presenter with the view
    this.presenter = new AddStoryPresenter({
      view: this.view
    });
    
    // Initialize the presenter
    await this.presenter.init();
  }
}
