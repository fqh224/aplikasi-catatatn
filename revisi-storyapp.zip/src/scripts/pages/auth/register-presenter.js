// Presenter for Register page
import Auth from '../../data/auth';

export default class RegisterPresenter {
  constructor({ view }) {
    this.view = view;
    this.auth = new Auth();
  }

  async init() {
    this.view.registerFormSubmitHandler(this.handleFormSubmit.bind(this));
  }

  async handleFormSubmit(event) {
    event.preventDefault();
    
    const { name, email, password } = this.view.getFormValues();
    
    this.view.showLoading();
    
    const response = await this.auth.register({ name, email, password });
    
    if (response.error) {
      this.view.showError(response.message);
    } else {
      this.view.showSuccess();
      this.view.redirect('#/login');
    }
  }

  checkLoggedIn() {
    return this.auth.isUserLoggedIn();
  }
}
