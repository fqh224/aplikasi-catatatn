// Presenter for Story Detail page
import Story from '../../data/story';
import Auth from '../../data/auth';
import { parseActivePathname } from '../../routes/url-parser';
import { showFormattedDate } from '../../utils/index';
import Map from '../../utils/map';
import { saveStoryToDB, removeSavedStoryFromDB, getSavedStoryFromDB } from '../../data/indexed-db';

export default class StoryDetailPresenter {
  constructor({ view }) {
    this.view = view;
    this.story = new Story();
    this.auth = new Auth();
    this.map = null;
    this.currentStory = null;
  }

  async init() {
    try {
      await this.loadStoryDetail();
    } catch (error) {
      console.error('Error initializing presenter:', error);
      this.view.showError('Failed to initialize page. Please try again later.');
    }
  }

  async loadStoryDetail() {
    const { id } = parseActivePathname();
    
    if (!this.auth.isUserLoggedIn()) {
      this.view.showAuthRequired();
      return;
    }
    
    try {
      this.view.showLoading();
      
      const response = await this.story.getStoryById(id);
      
      if (response.error) {
        this.view.showError(response.message);
        return;
      }
      
      const { story } = response;
      this.currentStory = story;
      
      // Display story and get map container if available
      const mapContainer = this.view.displayStoryDetail(story);
      
      // Check if story is already saved
      await this.checkSaveStatus();
      
      // Register save/delete handlers
      this.view.registerSaveStoryHandler(this.handleSaveStory.bind(this));
      this.view.registerDeleteStoryHandler(this.handleDeleteStory.bind(this));
      
      if (story.lat && story.lon && mapContainer) {
        await this.initMap(story, mapContainer);
      }
      
    } catch (error) {
      console.error(error);
      this.view.showError('Failed to load story details. Please try again later.');
    }
  }

  async checkSaveStatus() {
    if (!this.currentStory) return;
    
    try {
      const savedStory = await getSavedStoryFromDB(this.currentStory.id);
      this.view.updateSaveButtonState(!!savedStory);
    } catch (error) {
      console.error('Error checking save status:', error);
    }
  }

  async handleSaveStory() {
    if (!this.currentStory) return;
    
    try {
      await saveStoryToDB(this.currentStory);
      this.view.updateSaveButtonState(true);
      this.showToast('Story saved successfully!', 'success');
    } catch (error) {
      console.error('Error saving story:', error);
      this.showToast('Failed to save story', 'error');
    }
  }

  async handleDeleteStory() {
    if (!this.currentStory) return;
    
    // Show confirmation dialog
    const confirmed = confirm('Are you sure you want to delete this saved story?');
    if (!confirmed) return;
    
    try {
      await removeSavedStoryFromDB(this.currentStory.id);
      this.view.updateSaveButtonState(false);
      this.showToast('Story deleted from saved', 'success');
    } catch (error) {
      console.error('Error deleting saved story:', error);
      this.showToast('Failed to delete story', 'error');
    }
  }

  showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = this.getToastIcon(type);
    
    toast.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span>${message}</span>
      <button class="toast-close">&times;</button>
    `;

    // Add to container
    toastContainer.appendChild(toast);

    // Show toast
    setTimeout(() => {
      toast.classList.add('show');
    }, 100);

    // Auto remove after 3 seconds
    setTimeout(() => {
      this.removeToast(toast);
    }, 3000);

    // Close button handler
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
      this.removeToast(toast);
    });
  }

  getToastIcon(type) {
    switch (type) {
      case 'success': return '✓';
      case 'error': return '✕';
      case 'info': return 'ℹ';
      default: return 'ℹ';
    }
  }

  removeToast(toast) {
    toast.classList.remove('show');
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }

  async initMap(story, mapContainer) {
    try {
      this.map = new Map({ mapElement: mapContainer });
      await this.map.initMap(story.lat, story.lon);
      
      const popupContent = `
        <div class="map-popup">
          <h3>${story.name}'s Story Location</h3>
          <p>Posted on: ${showFormattedDate(story.createdAt)}</p>
          <p>Coordinates: ${story.lat.toFixed(4)}, ${story.lon.toFixed(4)}</p>
        </div>
      `;
      
      this.map.setMarker(story.lat, story.lon, popupContent);
    } catch (error) {
      console.error('Failed to initialize map:', error);
      // We continue even if the map fails
    }
  }
}
