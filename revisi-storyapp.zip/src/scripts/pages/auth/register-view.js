// View for Register page
export default class RegisterView {
  constructor() {
    this.registerForm = null;
    this.messageContainer = null;
  }

  getTemplate() {
    return `
      <section class="container auth-container">
        <h1 class="auth-title">Register</h1>
        <form id="registerForm" class="auth-form">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required placeholder="Your name">
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required placeholder="example@email.com">
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required minlength="8" placeholder="Minimum 8 characters">
          </div>
          <div id="registerMessage" class="form-message"></div>
          <button type="submit" class="auth-button">Register</button>
          <p class="auth-redirect">
            Already have an account? <a href="#/login">Login here</a>
          </p>
        </form>
      </section>
    `;
  }

  initElements() {
    this.registerForm = document.getElementById('registerForm');
    this.messageContainer = document.getElementById('registerMessage');
  }

  registerFormSubmitHandler(handler) {
    this.registerForm.addEventListener('submit', handler);
  }

  getFormValues() {
    return {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      password: document.getElementById('password').value
    };
  }

  showLoading() {
    this.messageContainer.textContent = 'Registering...';
    this.messageContainer.classList.remove('error');
    this.messageContainer.classList.add('info');
  }

  showError(message) {
    this.messageContainer.textContent = message;
    this.messageContainer.classList.remove('info', 'success');
    this.messageContainer.classList.add('error');
  }

  showSuccess(message) {
    this.messageContainer.textContent = message || 'Registration successful! Please login.';
    this.messageContainer.classList.remove('error', 'info');
    this.messageContainer.classList.add('success');
  }

  redirect(path) {
    setTimeout(() => {
      window.location.hash = path;
    }, 1500);
  }
}
